function angle_Type(num){
  
    if(90 == num)
        return "Right Angle";
    else if(180 == num)
        return "Straight Angle";
    else if(0 < num && num < 90)
        return "Acute Angle";
    else if(90 < num && num < 180)
        return "Obtuse Angle";
    else 
        return "Not an angle";
}

console.log(angle_Type(45))
console.log(angle_Type(90))
console.log(angle_Type(145))
console.log(angle_Type(180))